if settings.startup["bobmods-inserters-long2"].value == true and not data.raw.technology["long-inserters-2"] then
data:extend(
{
  {
    type = "technology",
    name = "long-inserters-2",
    icon = "__bobinserters__/graphics/icons/technology/long-inserters.png",
    icon_size = 128,
    effects =
    {
    },
    prerequisites =
    {
      "long-inserters-1",
      "logistics-2",
    },
    unit =
    {
      count = 50,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
      },
      time = 10
    },
    order = "a-f-a-2",
  },
}
)
end


if settings.startup["bobmods-inserters-more2"].value == true and not data.raw.technology["more-inserters-2"] then
data:extend(
{
  {
    type = "technology",
    name = "more-inserters-2",
    icon = "__bobinserters__/graphics/icons/technology/more-inserters.png",
    icon_size = 128,
    effects =
    {
    },
    prerequisites =
    {
      "more-inserters-1",
      "logistics-2",
    },
    unit =
    {
      count = 50,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
      },
      time = 10
    },
    order = "a-f-c-2",
  },
}
)
end